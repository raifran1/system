from django.apps import AppConfig


class OcorenciaFuncionarioConfig(AppConfig):
    name = 'ocorencia_funcionario'
