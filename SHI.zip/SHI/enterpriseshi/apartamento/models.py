from django.db import models

# Create your models here.

class apartamento (model.Models):
    Apart_NoEmpresa = models.IntegerField(max_lenght=11 , verbose_name="Apart_NoEmpresa")
    Apart_NoAPT = models.IntegerField(max_lenght=11,verbose_name="Apart_NoAPT")
    Apart_Impressora = models.CharField(max_lenght=40,verbose_name="Apart_Impressora")
    Apart_NoTipo = models.CharField(max_lenght=2,verbose_name="Apart_NoTipo")
    Apart_NoDeposito = models.IntegerField(max_lenght=11, )
    Apart_ApartCalcHora = models.CharField(max_lenght=1,verbose_name="Apart_ApartCalcHora")
    Apart_Situacao = models.CharField(max_lenght=1,verbose_name="Apart_Situacao")
    Apart_Video = models.CharField(max_lenght=100,verbose_name="Apart_Video")
    Apart_Liga = models.CharField(max_lenght=3,verbose_name="Apart_Liga")
    Apart_Desliga = models.CharField(max_lenght=3,verbose_name="Apart_Desliga")
    Apart_Ligado = models.CharField(max_lenght=1,verbose_name="Apart_Ligado")
    Apart_Desligado = models.CharField(max_lenght=1,verbose_name="Apart_Desligado")
    Apart_UsaLigAuto = models.CharField(max_lenght=1,verbose_name="Apart_UsaLigAuto")
