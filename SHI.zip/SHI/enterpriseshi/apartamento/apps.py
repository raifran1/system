from django.apps import AppConfig


class ApartamentoConfig(AppConfig):
    name = 'apartamento'
