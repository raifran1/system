from django.apps import AppConfig


class DespesasConfig(AppConfig):
    name = 'despesas'
