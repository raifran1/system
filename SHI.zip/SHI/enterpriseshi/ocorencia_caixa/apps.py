from django.apps import AppConfig


class OcorenciaCaixaConfig(AppConfig):
    name = 'ocorencia_caixa'
