from django.apps import AppConfig


class MesaConfig(AppConfig):
    name = 'mesa'
