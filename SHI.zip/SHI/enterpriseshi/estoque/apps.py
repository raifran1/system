from django.apps import AppConfig


class EstoqueConfig(AppConfig):
    name = 'estoque'
