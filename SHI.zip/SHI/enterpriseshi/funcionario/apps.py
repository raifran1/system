from django.apps import AppConfig


class FuncionarioConfig(AppConfig):
    name = 'funcionario'
