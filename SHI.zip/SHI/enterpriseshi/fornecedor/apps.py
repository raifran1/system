from django.apps import AppConfig


class FornecedorConfig(AppConfig):
    name = 'fornecedor'
