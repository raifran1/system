from django.apps import AppConfig


class ProdutoConjuntoConfig(AppConfig):
    name = 'produto_conjunto'
