from django.apps import AppConfig


class EstoqueMovimentoConfig(AppConfig):
    name = 'estoque_movimento'
