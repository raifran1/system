from django.apps import AppConfig


class NaturesaOperacaoConfig(AppConfig):
    name = 'naturesa_operacao'
