from django.apps import AppConfig


class RecebProdutoConfig(AppConfig):
    name = 'receb_produto'
