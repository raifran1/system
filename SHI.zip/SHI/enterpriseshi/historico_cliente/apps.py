from django.apps import AppConfig


class HistoricoClienteConfig(AppConfig):
    name = 'historico_cliente'
