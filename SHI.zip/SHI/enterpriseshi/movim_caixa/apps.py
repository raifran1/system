from django.apps import AppConfig


class MovimCaixaConfig(AppConfig):
    name = 'movim_caixa'
