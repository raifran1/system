from django.apps import AppConfig


class FaturaMessageConfig(AppConfig):
    name = 'fatura_message'
