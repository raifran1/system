from django.db import models

# Create your models here.

class apart_historico(model.Models):
    AH_Nointerno = models.IntegerField(max_lenght=11,verbose_name="AH_Nointerno")
    AH_NoApto = models.IntegerField(max_lenght=11,verbose_name="AH_Nointerno")
    AH_Historico = models.CharField(max_lenght=30,verbose_name="AH_Historico")
    AH_Data = models.DateField(default=datetime.datetime.today)
    AH_Hora = models.TimeField(blank=True)
    AH_NoUsuario = models.IntegerField(max_lenght=11,verbose_name="AH_NoUsuario")
