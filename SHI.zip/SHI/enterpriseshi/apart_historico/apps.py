from django.apps import AppConfig


class ApartHistoricoConfig(AppConfig):
    name = 'apart_historico'
