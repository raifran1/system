from django.apps import AppConfig


class FaturaComandMsgConfig(AppConfig):
    name = 'fatura_comand_msg'
