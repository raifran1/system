from django.apps import AppConfig


class OssConfig(AppConfig):
    name = 'oss'
