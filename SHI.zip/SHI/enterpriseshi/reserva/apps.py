from django.apps import AppConfig


class ReservaConfig(AppConfig):
    name = 'reserva'
