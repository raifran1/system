from django.apps import AppConfig


class ResumoConsumoConfig(AppConfig):
    name = 'resumo_consumo'
