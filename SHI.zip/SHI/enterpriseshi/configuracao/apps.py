from django.apps import AppConfig


class ConfiguracaoConfig(AppConfig):
    name = 'configuracao'
