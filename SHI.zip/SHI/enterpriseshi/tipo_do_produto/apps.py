from django.apps import AppConfig


class TipoDoProdutoConfig(AppConfig):
    name = 'tipo_do_produto'
