from django.apps import AppConfig


class DesmTipoPagtoDefConfig(AppConfig):
    name = 'desm_tipo_pagto_def'
