from django.db import models

# Create your models here.

class conscheq(model.Models):
    CC_Nointerno = models.IntegerField(max_lenght=11,verbose_name="CC_Nointerno")
    CC_NoLoja = models.IntegerField(max_lenght=11,verbose_name="CC_NoLoja")
    CC_LjAbreviacao = models.CharField(max_lenght=3,verbose_name="CC_LjAbreviacao")
    CC_Pdv = models.IntegerField(max_lenght=11,verbose_name="CC_Pdv")
    CC_NoCliente = models.IntegerField(max_lenght=11,verbose_name="CC_NoCliente")
    CC_NomeCli = models.IntegerField(max_lenght=11,verbose_name="CC_NomeCliente")
    CC_Cpf_CgcCli = models.CharField(max_lenght=40,verbose_name="CC_Cpf_CgcCli")
    CC_NoCheque = models.IntegerField(max_lenght=40,verbose_name="CC_NoCheque")
    CC_SerieChec = models.CharField(max_lenght=4,verbose_name="CC_SerieChec")
    CC_BcoDep = models.IntegerField(max_lenght=11,verbose_name="CC_BcoDep")
    CC_ApelBcoDep = models.CharField(max_lenght=20,verbose_name="CC_ApelBcoDep")
    CC_DtDep = models.CharField(max_lenght=20,verbose_name="CC_DtDep")
    CC_Valor = models.FloatField()
    CC_Situacao = models.CharField(max_lenght=3,verbose_name="CC_Situacao")
