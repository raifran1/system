from django.apps import AppConfig


class ConcheqConfig(AppConfig):
    name = 'concheq'
