from django.apps import AppConfig


class TipoReservaConfig(AppConfig):
    name = 'tipo_reserva'
