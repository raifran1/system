from django.apps import AppConfig


class EmpresaClienteConfig(AppConfig):
    name = 'empresa_cliente'
