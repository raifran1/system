from django.apps import AppConfig


class TipoPagtoConfig(AppConfig):
    name = 'tipo_pagto'
