from django.apps import AppConfig


class ProdutoPrecoConfig(AppConfig):
    name = 'produto_preco'
