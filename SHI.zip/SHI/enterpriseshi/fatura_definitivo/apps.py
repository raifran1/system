from django.apps import AppConfig


class FaturaDefinitivoConfig(AppConfig):
    name = 'fatura_definitivo'
