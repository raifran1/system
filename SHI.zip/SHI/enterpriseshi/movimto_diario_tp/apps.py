from django.apps import AppConfig


class MovimtoDiarioTpConfig(AppConfig):
    name = 'movimto_diario_tp'
