from django.apps import AppConfig


class TipoConfig(AppConfig):
    name = 'tipo'
