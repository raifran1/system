from django.apps import AppConfig


class FaturaMovimentoConfig(AppConfig):
    name = 'fatura_movimento'
