from django.db import models

# Create your models here.

class alarme (model.Models):
    Ala_noFatura = models.IntegerField(max_length=11,verbose_name="Ala_noFatura")
    Ala_Data = models.DateField(default=datetime.datetime.today)
    Ala_Hora = models.CharField(max_length=5,verbose_name="Ala_Hora")
    Ala_Observacao = models.CharField(max_length=80,verbose_name="Ala_Observacao")
    
