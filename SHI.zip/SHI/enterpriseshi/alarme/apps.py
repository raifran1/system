from django.apps import AppConfig


class AlarmeConfig(AppConfig):
    name = 'alarme'
