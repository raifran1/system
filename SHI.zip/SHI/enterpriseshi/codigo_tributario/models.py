from django.db import models

# Create your models here.

class codigo_tributario(model.Models):
    CodT_NoCtrib = models.CharField(max_lenght=3,verbose_name="CodT_NoCtrib")
    CodT_Nome = models.CharField(max_lenght=40,verbose_name="CodT_Nome")
    CodT_Aliquota = models.FloatField()
    CodT_BaseReduz = models.FloatField()
    CodT_Situacao = models.IntegerField(max_lenght=11,verbose_name="CodT_Situacao")
