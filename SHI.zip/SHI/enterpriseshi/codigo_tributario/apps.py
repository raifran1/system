from django.apps import AppConfig


class CodigoTributarioConfig(AppConfig):
    name = 'codigo_tributario'
