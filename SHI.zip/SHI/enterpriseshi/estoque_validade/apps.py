from django.apps import AppConfig


class EstoqueValidadeConfig(AppConfig):
    name = 'estoque_validade'
