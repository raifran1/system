from django.apps import AppConfig


class FuncaoConfig(AppConfig):
    name = 'funcao'
