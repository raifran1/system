from django.apps import AppConfig


class ProdutoFaturaConfig(AppConfig):
    name = 'produto_fatura'
