from django.apps import AppConfig


class ObservacaoFaturaConfig(AppConfig):
    name = 'observacao_fatura'
