from django.apps import AppConfig


class RequisicaoConfig(AppConfig):
    name = 'requisicao'
