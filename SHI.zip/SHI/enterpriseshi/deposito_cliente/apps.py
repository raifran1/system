from django.apps import AppConfig


class DepositoClienteConfig(AppConfig):
    name = 'deposito_cliente'
