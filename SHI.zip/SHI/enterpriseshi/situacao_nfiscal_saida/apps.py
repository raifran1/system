from django.apps import AppConfig


class SituacaoNfiscalSaidaConfig(AppConfig):
    name = 'situacao_nfiscal_saida'
