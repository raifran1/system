from django.apps import AppConfig


class MovimtoDiarioPgtoConfig(AppConfig):
    name = 'movimto_diario_pgto'
