from django.apps import AppConfig


class DepositoConfig(AppConfig):
    name = 'deposito'
