from django.apps import AppConfig


class ProdutoFaturaDefConfig(AppConfig):
    name = 'produto_fatura_def'
