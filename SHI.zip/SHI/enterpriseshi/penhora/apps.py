from django.apps import AppConfig


class PenhoraConfig(AppConfig):
    name = 'penhora'
