from django.apps import AppConfig


class FatmovcontroleConfig(AppConfig):
    name = 'fatmovcontrole'
