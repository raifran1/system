from django.apps import AppConfig


class InformAdicProdNfConfig(AppConfig):
    name = 'inform_adic_prod_nf'
