from django.apps import AppConfig


class ProdutoFaturaObsConfig(AppConfig):
    name = 'produto_fatura_obs'
