from django.apps import AppConfig


class NotasFiscaisSaidaConfig(AppConfig):
    name = 'notas_fiscais_saida'
