from django.apps import AppConfig


class EmpresaConfig(AppConfig):
    name = 'empresa'
