from django.apps import AppConfig


class DesmTipoPagtoConfig(AppConfig):
    name = 'desm_tipo_pagto'
