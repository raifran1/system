from django.apps import AppConfig


class PdvconfConfig(AppConfig):
    name = 'pdvconf'
