from django.apps import AppConfig


class ProdutoFaturaDesmPrincConfig(AppConfig):
    name = 'produto_fatura_desm_princ'
