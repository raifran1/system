from django.apps import AppConfig


class PlanoContasConfig(AppConfig):
    name = 'plano_contas'
