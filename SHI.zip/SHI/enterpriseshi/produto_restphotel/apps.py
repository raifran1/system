from django.apps import AppConfig


class ProdutoRestphotelConfig(AppConfig):
    name = 'produto_restphotel'
