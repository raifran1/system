from django.apps import AppConfig


class TipoNfSaidaConfig(AppConfig):
    name = 'tipo_nf_saida'
