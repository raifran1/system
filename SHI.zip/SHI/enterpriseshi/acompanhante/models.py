from django.db import models

# Create your models here.

class acompanhante(model.Models):
    Acomp_NoFatura = models.IntegerField(max_length=11,verbose_name="Acomp_NoFatura")
    Acomp_NomeAcomp = models.CharField(max_length=50,verbose_name="Acomp_NomeAcomp")
    Acomp_crianca = models.CharField(max_length=50,verbose_name="Acomp_crianca")
