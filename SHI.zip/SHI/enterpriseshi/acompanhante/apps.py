from django.apps import AppConfig


class AcompanhanteConfig(AppConfig):
    name = 'acompanhante'
