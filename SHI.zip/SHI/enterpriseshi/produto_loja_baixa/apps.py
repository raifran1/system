from django.apps import AppConfig


class ProdutoLojaBaixaConfig(AppConfig):
    name = 'produto_loja_baixa'
