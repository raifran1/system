from django.apps import AppConfig


class TipoLigacaoConfig(AppConfig):
    name = 'tipo_ligacao'
