from django.apps import AppConfig


class ProdutoFaturaDesmComplConfig(AppConfig):
    name = 'produto_fatura_desm_compl'
