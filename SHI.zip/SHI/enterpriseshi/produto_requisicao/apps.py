from django.apps import AppConfig


class ProdutoRequisicaoConfig(AppConfig):
    name = 'produto_requisicao'
