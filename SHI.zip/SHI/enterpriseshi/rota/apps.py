from django.apps import AppConfig


class RotaConfig(AppConfig):
    name = 'rota'
