from django.apps import AppConfig


class CodigoFiscalOperacaoConfig(AppConfig):
    name = 'codigo_fiscal_operacao'
