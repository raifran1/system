from django.db import models

# Create your models here.

class codigo_fiscal_operacao(model.Models):
    Cfo_CFO = models.IntegerField(max_lenght=11,verbose_name="Cfo_CFO")
    Cfo_Nome = models.CharField(max_lenght=40,verbose_name="Cfo_Nome")
    Cfo_EntSai = models.CharField(max_lenght=1,verbose_name="Cfo_EntSai")
