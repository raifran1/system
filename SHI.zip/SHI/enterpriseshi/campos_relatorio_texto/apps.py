from django.apps import AppConfig


class CamposRelatorioTextoConfig(AppConfig):
    name = 'campos_relatorio_texto'
