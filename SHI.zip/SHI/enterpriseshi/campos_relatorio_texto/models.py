from django.db import models

# Create your models here.

class campos_relatorio_texto(model.Models):
    CRT_Modulo = models.IntegerField(max_lenght=11,verbose_name="CRT_Modulo")
    CRT_Campo = models.CharField(max_lenght=25,verbose_name="CRT_Campo")
    CRT_Tamanho = models.IntegerField(max_lenght=11,verbose_name="CRT_Tamanho")
    CRT_Precisao = models.IntegerField(max_lenght=11,verbose_name="CRT_Precisao")
