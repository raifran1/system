from django.apps import AppConfig


class CentroDeLucroConfig(AppConfig):
    name = 'centro_de_lucro'
