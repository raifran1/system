from django.db import models

# Create your models here.

class centro_de_lucro(model.Models):
    CL_NoCl = models.IntegerField(max_lenght=11,verbose_name="CL_NoCl")
    CL_Nome = models.CharField(max_lenght=35,verbose_name="CL_Nome")
