from django.apps import AppConfig


class ProdutoNfSaidaConfig(AppConfig):
    name = 'produto_nf_saida'
