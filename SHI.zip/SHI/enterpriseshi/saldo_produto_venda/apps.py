from django.apps import AppConfig


class SaldoProdutoVendaConfig(AppConfig):
    name = 'saldo_produto_venda'
