from django.apps import AppConfig


class MovimtoDiarioOcupConfig(AppConfig):
    name = 'movimto_diario_ocup'
