from django.apps import AppConfig


class HistoricoMsgConfig(AppConfig):
    name = 'historico_msg'
