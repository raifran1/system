from django.apps import AppConfig


class TipoEstoqueMovimentoConfig(AppConfig):
    name = 'tipo_estoque_movimento'
