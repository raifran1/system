from django.apps import AppConfig


class SaldoEstoqueConfig(AppConfig):
    name = 'saldo_estoque'
