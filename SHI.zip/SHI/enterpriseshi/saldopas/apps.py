from django.apps import AppConfig


class SaldopasConfig(AppConfig):
    name = 'saldopas'
